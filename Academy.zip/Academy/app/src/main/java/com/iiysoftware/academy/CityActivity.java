package com.iiysoftware.academy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.LinearLayout;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.iiysoftware.academy.Adapters.CitiesAdapter;
import com.iiysoftware.academy.Adapters.LocalAreaAdapter;
import com.iiysoftware.academy.Models.Cities;

import javax.annotation.Nullable;

public class CityActivity extends AppCompatActivity {

    private RecyclerView citiesList;
    private LinearLayoutManager layoutManager;
    private CitiesAdapter adapter;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city);

        String state_id = getIntent().getStringExtra("state_id");

        Toolbar toolbar = findViewById(R.id.city_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Cities");

        citiesList = findViewById(R.id.cities_list);
        layoutManager = new LinearLayoutManager(this);
        citiesList.setHasFixedSize(true);
        citiesList.setLayoutManager(layoutManager);


        db = FirebaseFirestore.getInstance();

        Query query = db.collection("Cities").document("Punjab")
                .collection("CityData");
        final FirestoreRecyclerOptions<Cities> options = new FirestoreRecyclerOptions.Builder<Cities>()
                .setQuery(query, Cities.class)
                .build();

        adapter = new CitiesAdapter(getApplicationContext(), options);
        citiesList.setAdapter(adapter);

        adapter.setOnItemClick(new CitiesAdapter.OnItemClick() {
            @Override
            public void getPosition(String userId) {
                String city_name = userId;
                Intent intent = new Intent(CityActivity.this, LocalAreaActivity.class);
                intent.putExtra("city_name", city_name);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
