package com.iiysoftware.academy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.iiysoftware.academy.Adapters.CitiesAdapter;
import com.iiysoftware.academy.Adapters.LocalAreaAdapter;
import com.iiysoftware.academy.Models.Cities;
import com.iiysoftware.academy.Models.LocalAreas;

public class LocalAreaActivity extends AppCompatActivity {

    private RecyclerView areaList;
    private LinearLayoutManager layoutManager;
    private LocalAreaAdapter adapter;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_area);

        String local = getIntent().getStringExtra("city_name");

        Toolbar toolbar = findViewById(R.id.area_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Local Areas");

        areaList = findViewById(R.id.area_list);
        layoutManager = new LinearLayoutManager(this);
        areaList.setHasFixedSize(true);
        areaList.setLayoutManager(layoutManager);


        db = FirebaseFirestore.getInstance();

        Query query = db.collection("Cities").document("Punjab")
                .collection("CityData").document(local).collection("AreaData");
        final FirestoreRecyclerOptions<LocalAreas> options = new FirestoreRecyclerOptions.Builder<LocalAreas>()
                .setQuery(query, LocalAreas.class)
                .build();

        adapter = new LocalAreaAdapter(getApplicationContext(), options);
        areaList.setAdapter(adapter);

        adapter.setOnItemClick(new LocalAreaAdapter.OnItemClick() {
            @Override
            public void getPosition(String userId) {
                String area_name = userId;
                Intent intent = new Intent(LocalAreaActivity.this, DashActivity.class);
                intent.putExtra("area_name", area_name);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();

    }
}
